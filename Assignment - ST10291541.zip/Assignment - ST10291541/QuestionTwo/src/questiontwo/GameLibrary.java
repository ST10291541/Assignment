/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questiontwo;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author elishastephen
 */
public class GameLibrary extends Game{
    
    String searchQuery;
    String deleteQuery;
    Scanner kb = new Scanner(System.in);

    public GameLibrary(String gameName, int gameYear, String gamePlatform, String gameGenre, int gameRating) {
        super(gameName, gameYear, gamePlatform, gameGenre, gameRating);
    }

    public void searchGame(String searchQuery) {
        
        boolean found = false;
        for (int i = 0; i < gameNames.size(); i++) {
            if (searchQuery.equals(gameNames.get(i))) {
                System.out.println("Year Released: " + gameYears.get(i));
                System.out.println("Game Platform: " + gamePlatforms.get(i));
                System.out.println("Game Genre: " + gameGenres.get(i));
                System.out.println("Game Rating: " + gameRatings.get(i));
                found = true;
                break;
            } // end if
        } // end for
        if (!found) {
            System.out.println("Game not found");
        } // end if
    } // end search
    
    /*
            int index = studentsID.indexOf(studentSearchID);
        return index;
    */

    public void deleteGame(String deleteQuery) {
       
        boolean found = false;
        for (int i = 0; i < gameNames.size(); i++) {
            if (deleteQuery.equals(gameNames.get(i))) {
                gameNames.remove(i);
                gameYears.remove(i);
                gamePlatforms.remove(i);
                gameGenres.remove(i);
                gameRatings.remove(i);
                System.out.println("Game was deleted. ");
                found = true;
                break;
            } // end if
        } // end for
        
        if (!found) {
            System.out.println("Game not found");
        } // end if
    } // end delete
    
    
    public void bestGame() {
        
        int highestRate = 0; // Initialize with the smallest possible integer
        ArrayList<String> bestGame = new ArrayList<String>();

        for (int i = 0; i < gameRatings.size(); i++) {
            int rate = gameRatings.get(i);

            if (rate > highestRate) {
                highestRate = rate;
                bestGame.clear();
                // Adding game info to bestGames
                bestGame.add(gameNames.get(i) + " " + gameYears.get(i) + " " + gamePlatforms.get(i) + " " + gameGenres.get(i)); 
            } else if (rate == highestRate) {
                bestGame.add("\n " + gameNames.get(i) + " " + gameYears.get(i) + " " + gamePlatforms.get(i) + " " + gameGenres.get(i));
            }
        }

        // bestGames contains the details of the highest-rated game(s)
        System.out.println("Highest Rating: " + highestRate);
        System.out.println("Best Games: " + bestGame);
    } // end method
    
    
}
