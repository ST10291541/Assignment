/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questiontwo;

import java.util.ArrayList;

/**
 *
 * @author elishastephen
 */
public class Game {
    
     String gameName;
     int gameYear;
     String gamePlatform;
     String gameGenre;
     int gameRating;
     
     ArrayList <String> gameNames = new ArrayList <String> ();
     ArrayList <Integer> gameYears = new ArrayList <Integer> ();
     ArrayList <String> gamePlatforms = new ArrayList <String> ();
     ArrayList <String> gameGenres = new ArrayList <String> ();
     ArrayList <Integer> gameRatings = new ArrayList <Integer> ();

     
    public Game(String gameName, int gameYear, String gamePlatform, String gameGenre, int gameRating) {

       this.gameName = gameName;
       this.gameYear = gameYear;
       this.gamePlatform = gamePlatform;
       this.gameGenre = gameGenre;
       this.gameRating = gameRating;
    } // end constructor
    
     
    public void addGame(String gameName, int gameYear, String gamePlatform, String gameGenre, int gameRating) {

        gameNames.add(gameName);
        gameYears.add(gameYear);
        gamePlatforms.add(gamePlatform);
        gameGenres.add(gameGenre);
        gameRatings.add(gameRating);
       
    } // end method
    
    public void displayAll() {
     for (int i = 0; i < gameNames.size(); i++) {
        
            System.out.println("Game Name: " + gameNames.get(i));
            System.out.println("Year Released : " + gameYears.get(i));
            System.out.println("Game Platform: " + gamePlatforms.get(i));
            System.out.println("Game Genre: " + gameGenres.get(i));
            System.out.println("Game Rating: " + gameRatings.get(i));  
        } // end for
    } // end display
    
}
