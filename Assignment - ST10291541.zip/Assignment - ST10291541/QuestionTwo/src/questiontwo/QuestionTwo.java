/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questiontwo;

import java.util.Scanner;

/**
 *
 * @author elishastephen
 */
public class QuestionTwo {
final static Scanner kb = new Scanner(System.in);

    public static void main(String[] args) {
        GameLibrary gl = new GameLibrary(" ", 0, " ", " ", 0);
        
        boolean quit = false;
        

        while (!quit) {
            System.out.println("Game Library Managemnt System: " + "\n");
            System.out.println("Enter (1) to add a game " + "\n" +
                               "Enter (2) to search for a game " + "\n" +
                               "Enter (3) to delete a game " + "\n" + 
                               "Enter (4) to view all games " + "\n" +
                               "Enter (5) to find the best game " + "\n" +
                               "Enter (6) to exit the application");
            int option = kb.nextInt();
            
            switch (option) {
                case 1: 
                    System.out.println("Please enter the name of the game");
                    String gameName = kb.next();
                    
                    System.out.println("Please enter the year the game was released");
                    int gameYear = kb.nextInt();
                    
                    System.out.println("Please enter the gaming platform used");
                    String gamePlatform = kb.next();
                    
                    System.out.println("Please enter the genre for the game");
                    String gameGenre = kb.next();
                    
                    System.out.println("Please enter the game rating. " + "\n" + "Enter a number from 1 - 10, with 1 being the lowest and 10 the highest.");
                    int gameRating = kb.nextInt(); 
        
                    while ((gameRating < 1 ) || (gameRating > 10)) {
                        System.out.println("Invalid entry, please try again."); 
                        gameRating = kb.nextInt();  
                    } // end while
                    
                    gl.addGame(gameName, gameYear, gamePlatform, gameGenre, gameRating);
                    break;
                    
                case 2: 
                    
                    System.out.println("Enter the name of the game you wish to search for.");
                    String searchQuery = kb.next();
                    gl.searchGame(searchQuery);
                    break;
                    
                case 3: 
                    
                    System.out.println("Enter the name of the game you wish to search for.");
                    String deleteQuery = kb.next();
                    gl.deleteGame(deleteQuery);
                    break;
                case 4: gl.displayAll();
                    break;
                case 5:
                    gl.bestGame();
                    break;
                case 6: System.exit(0);
                    break;
                default: System.out.println("Invalid Entry, Please try again");
                    break;
            } // end switch case
            
        } // end while
        
    } // end main
    
} // end class
