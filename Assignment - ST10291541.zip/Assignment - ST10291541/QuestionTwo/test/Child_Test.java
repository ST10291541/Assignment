/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import questiontwo.GameLibrary;

/**
 *
 * @author elishastephen
 */
public class Child_Test {
    
    public Child_Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of searchGame method, of class GameLibrary.
     */
    @Test
    public void testSearchGame() {
        System.out.println("searchGame");
        
        String searchQuery = "Mario";
        GameLibrary instance = new GameLibrary(" ", 0, " ", " ", 0);
        instance.addGame("Mario", 2009, "XBox", "Cartoon", 7);
        instance.searchGame(searchQuery);
    } // end test

    /**
     * Test of deleteGame method, of class GameLibrary.
     */
    @Test
    public void testDeleteGame() {
        System.out.println("deleteGame");
        String deleteQuery = "Bros";
        GameLibrary instance = new GameLibrary(" ", 0, " ", " ", 0);
        instance.addGame("Bros", 2008, "PS", "Comedy", 9);
        instance.deleteGame(deleteQuery);
    } // end test

    /**
     * Test of bestGame method, of class GameLibrary.
     */
    @Test
    public void testBestGame() {
        System.out.println("bestGame");
        int rating = 8;
        GameLibrary instance = new GameLibrary(" ", 0, " ", " ", 0);
        instance.addGame("Fortnite", 2017, "Nintendo", "Actiony", 8);
        instance.bestGame();
    } // end test
    
}
