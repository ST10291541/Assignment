/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import questiontwo.Game;

/**
 *
 * @author elishastephen
 */
public class Parent_Test {
    
    public Parent_Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addGame method, of class Game.
     */
    @Test
    public void testAddGame() {
        System.out.println("addGame");
        String gameName = "Mario";
        int gameYear = 2009;
        String gamePlatform = "XBox";
        String gameGenre = "Cartoon";
        int gameRating = 7;
        Game instance = new Game(" ", 0, " ", "", 0);
        instance.addGame(gameName, gameYear, gamePlatform, gameGenre, gameRating);
        instance.displayAll();
    }

    /**
     * Test of displayAll method, of class Game.
     */
    @Test
    public void testDisplayAll() {
        System.out.println("displayAll");
        
        Game instance = new Game(" ", 0, " ", "", 0);
        instance.addGame("Mario", 2009, "XBox","Cartoon", 9);
        instance.addGame("Bros", 2008, "PS","Comedy", 10);
        instance.addGame("Sonic", 2015, "Nintendo","Action", 9);
        instance.displayAll();
    } // end test
    
}
