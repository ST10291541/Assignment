/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questionone;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author elishastephen
 */
public class QuestionOne {
    
    public static String choice;
    public static int studentID;
    public static String studentName;
    public static String studentAge;
    public static String studentEmail;
    public static String studentCourse;
    
    final static Scanner kb = new Scanner(System.in);
    private static ArrayList <String> studentsName = new ArrayList <String> ();
    private static ArrayList <Integer> studentsID = new ArrayList <Integer> ();
    private static ArrayList <String> studentsAge = new ArrayList <String> ();
    private static ArrayList <String> studentsEmail = new ArrayList <String> ();
    private static ArrayList <String> studentsCourse = new ArrayList <String> ();

    public static void main(String[] args) {
       housekeeping();
        
    }  
    
     public static void housekeeping() {
        
        System.out.println("Student Management Application");
        System.out.println("Enter (1) to launch the menu or any other key to quit \n");
        choice = kb.next();
        
        if (choice.equals("1")) {
            mainMenu();
        } else {
           System.exit(0);
        } // end if else
    } // end housekeeping
     
    
    public static void mainMenu() {
        
        Student student = new Student();
        int option;
        boolean quit = false;
        
        while (!quit) {
            
            System.out.println("Please select one of the following menu items: ");
            System.out.println("**********************************************");
            System.out.println("Enter (1) to capture a new student " + "\n" +
                               "Enter (2) to search for a student " + "\n" +
                               "Enter (3) to delete a student " + "\n" + 
                               "Enter (4) to print student report " + "\n" +
                               "Enter (5) to exit the application");
            option = kb.nextInt();

        switch (option) {
            
            case 1:  System.out.println("CAPTURE A NEW STUDENT ");
                     System.out.println("********************* ");
                
                System.out.println("Enter the student ID");
                studentID = kb.nextInt();
                while ( student.searchStudent(studentID) >= 0) {
                    System.out.println("Student Id already exists. Please re-enter student ID.");
                    studentID = kb.nextInt();
                } // end while
               
                
                System.out.println("Enter the student name");
                studentName = kb.next();
        
                System.out.println("Enter the student age");
                studentAge = kb.next();
                while (student.validAge(studentAge) != 0) {
                    System.out.println("You have entered an incorrect student age!!!");
                    System.out.println("Please re-enter the student age >>");
                    studentAge = kb.next();  
                } // end while

                System.out.println("Enter the student email");
                studentEmail = kb.next();
        
                System.out.println("Enter the student course");
                studentCourse = kb.next();
               
                Student.saveStudent(studentID, studentName, studentAge, studentEmail, studentCourse);
                System.out.println("Student added successfully!");
                break;
            
            case 2: 
                System.out.println("Please enter student ID to search");
                System.out.println("---------------------------------");
                int studentSearchID = kb.nextInt();
                
                int searchIndex = student.searchStudent(studentSearchID);

                if (searchIndex > 0){
                    System.out.println("Student ID: " + student.studentsID.get(searchIndex));
                    System.out.println("Student Name: "+ student.studentsName.get(searchIndex));
                    System.out.println("Student Age: "+ student.studentsAge.get(searchIndex));
                    System.out.println("Student Email: "+ student.studentsEmail.get(searchIndex));
                    System.out.println("Student Course: " +student.studentsCourse.get(searchIndex));
                }else{
                    System.out.println("Student with Student ID: " + studentSearchID + " was not found");
                }
                
                System.out.println("---------------------------------");
                break;
            
            case 3: 
                    System.out.println("Please enter student ID to delete:");
                    int deleteStudentID = kb.nextInt();                       
                                                                             
                    int deleteIndex = student.searchStudent(deleteStudentID);
                    if (deleteIndex == -1) {                                   
                        System.out.println("Student with student ID: " + deleteStudentID + " was not found.");
                    } else {                                                    
                        System.out.println("Are you sure you want to delete student " + deleteStudentID + " from the system? (Y/N)");
                        String confirm = kb.next();                             
                        if (confirm.equalsIgnoreCase("Y")) {        
                            System.out.println("-------------------------");
                            Student.deleteStudent(deleteIndex);
                     } // end if
                    } // end if else
                    System.out.println("Student with ID: " + deleteStudentID + " WAS deleted!");
                    
                    System.out.println("-------------------------");

                break;
            case 4: Student.studentReport();
                break;
            case 5: System.exit(0);
                break;
            default: System.out.println("Invalid entry, please try again");
                break;
        } // end switch
                
        } // end while
         
        } // end main
    
}

    

