/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questionone;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author elishastephen
 */
public class Student {
    
      
    final static Scanner kb = new Scanner(System.in);
    
    //array lists 
    public static ArrayList <Integer> studentsID = new ArrayList <Integer> ();
    public static ArrayList <String> studentsName = new ArrayList <String> ();
    public static ArrayList <String> studentsAge = new ArrayList <String> ();
    public static ArrayList <String> studentsEmail = new ArrayList <String> ();
    public static ArrayList <String> studentsCourse = new ArrayList <String> ();


    public static void saveStudent(int studentID, String studentName, String studentAge, String studentEmail, String studentCourse) { 

        studentsID.add(studentID);
        studentsName.add(studentName);
        studentsAge.add(studentAge);
        studentsEmail.add(studentEmail);
        studentsCourse.add(studentCourse);
    } // end of save
    
    
    public int validAge(String studentAge) {
      
    int correctAge = 0;
      try {
          if(Integer.parseInt(studentAge) < 16) {
            correctAge = -1;  
          } // end if
      } catch (Exception e) {
            correctAge = -2;
      } // end try catch
        return correctAge;
    } // end method

    public int searchStudent(int studentSearchID) { 
        
        int index = studentsID.indexOf(studentSearchID);
        return index;

    } // end method
    
   
    public static void deleteStudent(int deleteIndex) {
        
                studentsID.remove(deleteIndex);
                studentsName.remove(deleteIndex);
                studentsAge.remove(deleteIndex);
                studentsEmail.remove(deleteIndex);
                studentsCourse.remove(deleteIndex);
    } // end method
        
    
    public static void studentReport() {
        
        for (int i = 0; i < studentsID.size(); i++) {
        
            System.out.println("STUDENT " + (i + 1));
            System.out.println("---------------------------------");
            System.out.println("STUDENT ID: " + studentsID.get(i));
            System.out.println("STUDENT NAME: " + studentsName.get(i));
            System.out.println("STUDENT AGE: " + studentsAge.get(i));
            System.out.println("STUDENT EMAIL: " + studentsEmail.get(i));
            System.out.println("STUDENT COURSE: " + studentsCourse.get(i));  
        }
    } // end method
    
}
