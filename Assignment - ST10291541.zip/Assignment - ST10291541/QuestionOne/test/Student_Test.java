/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import questionone.Student;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author elishastephen
 */
public class Student_Test {
    
    public Student_Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of saveStudent method, of class Student.
     */
    @Test
    public void TestSaveStudent() {
        
        int result;
        
        System.out.println("saveStudent");
        
        int studentID = 10111;
        String studentName = "J.Bloggs";
        String studentAge = "19";
        String studentEmail = "jbloggs@ymail.com";
        String studentCourse = "disd";
        Student.saveStudent(studentID, studentName, studentAge, studentEmail, studentCourse);
        
        int expResult = -1;
        if (Student.studentsID.isEmpty()) {
            result = 1;
        } else {
            result = -1; 
        } // end if
        
        assertEquals(expResult, result);
    } // end save test
    
     /**
     * Test of searchStudent method, of class Student.
     */
    @Test
    public void TestSearchStudent () {
        
        System.out.println("searchStudent");
        int studentSearchID = 10111;
        Student instance = new Student();
        instance.saveStudent(10111, "J.Bloggs", "19", "jbloggs@ymail.com", "disd");
        
        int expResult = 0;
        int result = instance.searchStudent(studentSearchID);
        assertEquals(expResult, result);
        
    } // end right search test
    
    @Test
    public void TestSearchStudent_StudentNotFound() {
        
        System.out.println("searchStudent");
        int studentSearchID = 10114;
        Student instance = new Student();
        instance.saveStudent(10111, "J.Bloggs", "19", "jbloggs@ymail.com", "disd");
        
        int expResult = -1;
        int result = instance.searchStudent(studentSearchID);
        assertEquals(expResult, result);
        
    } // end wrong search test
    
    /**
     * Test of deleteStudent method, of class Student.
     */
    @Test
    public void TestDeleteStudent() {
        
        System.out.println("deleteStudent");
        int studentDeleteID = 10111;
        Student instance = new Student();
        instance.saveStudent(10111, "J.Bloggs", "19", "jbloggs@ymail.com", "disd");
        int deleteIndex = instance.searchStudent(studentDeleteID);
        instance.deleteStudent(deleteIndex);
        
        int expResult = -1;
        int result = instance.searchStudent(studentDeleteID);
        assertEquals(expResult, result);
 
    } // end right delete test
    
    @Test
    public void TestDeleteStudent_StudentNotFound() {
        
        System.out.println("deleteStudent");
        int studentDeleteID = 10114;
        Student instance = new Student();
        instance.saveStudent(10111, "J.Bloggs", "19", "jbloggs@ymail.com", "disd");
        
        int expResult = -1;
        int result = instance.searchStudent(studentDeleteID);
        assertEquals(expResult, result);
        
    } // end wrong delete test

    /**
     * Test of validAge method, of class Student.
     */
    @Test
    public void TestStudentAge_StudentAgeValid() {
        
        System.out.println("validAge");
        String studentAge = "19";
 
        Student instance = new Student();
        
        int expResult = 0;
        int result = instance.validAge(studentAge);
        assertEquals(expResult, result);
         
    } // end valid age test 
    
    
    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        
        System.out.println("invalidAge");
        String studentAge = "11";
        Student instance = new Student();
        
        int expResult = -1;
        int result = instance.validAge(studentAge);
        assertEquals(expResult, result);
         
    } // end invalid age test 
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        
        System.out.println("invalidAge");
        String studentAge = "c";
        Student instance = new Student();
        
        int expResult = -2;
        int result = instance.validAge(studentAge);
        assertEquals(expResult, result);
         
    } // end age chracter test 

    
}

